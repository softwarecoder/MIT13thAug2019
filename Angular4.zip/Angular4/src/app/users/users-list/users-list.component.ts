import { Component, OnInit, Input } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { UserService } from '../user.service';
import { User } from '../user';

@Component({
  selector: 'users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.css']
})
export class UsersListComponent implements OnInit {

  user: User;
  
  users: Observable<User[]>;

  constructor(private userService: UserService) {

  }

  ngOnInit() {
    this.reloadData();
  }
  
  updateActive(isActive: boolean, user: User) {
	this.user = user;  
    this.userService.updateUser(this.user.id,
      { name: this.user.name, age: this.user.age, active: isActive })
      .subscribe(
      data => {
        console.log(data);
        this.reloadData();
      },
      error => console.log(error));
  }

  deleteUser(user: User) {
	this.user = user; 
    this.userService.deleteUser(this.user.id)
      .subscribe(
      data => {
        console.log(data);
        this.reloadData();
      },
      error => console.log(error));
  }

  deleteUsers() {
    this.userService.deleteAll()
      .subscribe(
      data => {
        console.log(data);
        this.reloadData();
      },
      error => console.log('ERROR: ' + error));
  }

  reloadData() {
    this.users = this.userService.getUsersList();
  }
}
