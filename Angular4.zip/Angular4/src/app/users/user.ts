export class User {
  id: string;
  name: string;
  age: number;
  active: boolean;
}
