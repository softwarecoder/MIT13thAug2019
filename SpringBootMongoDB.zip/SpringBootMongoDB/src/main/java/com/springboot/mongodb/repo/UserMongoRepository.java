package com.springboot.mongodb.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.springboot.mongodb.model.User;

public interface UserMongoRepository extends MongoRepository<User, String> {

}
