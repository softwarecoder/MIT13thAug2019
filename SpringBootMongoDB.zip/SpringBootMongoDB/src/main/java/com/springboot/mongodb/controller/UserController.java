package com.springboot.mongodb.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.mongodb.model.User;
import com.springboot.mongodb.repo.UserMongoRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class UserController {

	@Autowired
	UserMongoRepository userRepository;

	@GetMapping("/users")
	public List<User> getAllUsers() {
		System.out.println("Get all Users...");

		return userRepository.findAll();
	}

	@PostMapping("/users/create")
	public User createUser(@Valid @RequestBody User user) {
		System.out.println("Create User: " + user.getName() + "...");

		user.setActive(false);
		return userRepository.save(user);
	}

	@PutMapping("/users/{id}")
	public ResponseEntity<User> updateUser(@PathVariable("id") String id, @RequestBody User user) {
		System.out.println("Update User with ID = " + id + "...");

		User userData = userRepository.findOne(id);
		if (user == null) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		userData.setName(user.getName());
		userData.setAge(user.getAge());
		userData.setActive(user.isActive());
		User updateduser = userRepository.save(userData);
		return new ResponseEntity<>(updateduser, HttpStatus.OK);
	}

	@DeleteMapping("/users/{id}")
	public ResponseEntity<String> deleteUser(@PathVariable("id") String id) {
		System.out.println("Delete User with ID = " + id + "...");

		userRepository.delete(id);
		
		return new ResponseEntity<>("User has been deleted!", HttpStatus.OK);
	}
	
	@DeleteMapping("/users/delete")
	public ResponseEntity<String> deleteAllUsers() {
		System.out.println("Delete All Users...");

		userRepository.deleteAll();
		
		return new ResponseEntity<>("All users have been deleted!", HttpStatus.OK);
	}
}
